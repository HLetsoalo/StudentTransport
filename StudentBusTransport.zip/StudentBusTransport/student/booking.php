<!DOCTYPE html>
<html lang="en">
<?php
    include 'connect.php';
    //cart Check
   
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
     


    ?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ST</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/css/animated-services.css">
    <link rel="stylesheet" href="assets/css/Customizable-Background--Overlay.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/FORM.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/login-full-page-bs4.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Login-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card-1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <nav class="navbar navbar-light navigation-clean">
        <div class="container">
            <div class="collapse navbar-collapse" id="navcol-1" style="font-size: 13px;">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="index.html" style="color: #a50544;">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.html" style="color: #a50544;">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="menu.html" style="color: #a50544;">Login | Register</a></li>
                </ul>
            </div>
            <div class="dropdown"><a aria-expanded="false" data-toggle="dropdown" href="#" style="color: #a50544;"><i class="icon ion-android-menu"></i>&nbsp;Menu</a>
                <div class="dropdown-menu">
                <a class="dropdown-item" href="account.php" style="font-size: 14px;color: #a50544;"><i class="fa fa-arrow-left"></i>&nbsp;Back</a></div>
            </div>
        </div>
    </nav>
    <h3 style="font-size: 16px;text-align: center;color: #a50544;">Student Bookings</h3>
    <div class="text-center profile-card" style="margin:15px;background-color:#ffffff;">
        <div>
            <div class="table-responsive" style="font-size: 14px;">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr style="background: #a50544;color: rgb(255,255,255);">
                            <th>#</th>
                            <th><i class="la la-share-alt"></i>Seat</th>
                            <th><i class="fa fa-info-circle"></i>&nbsp;Trip Info</th>
                            <th><i class="fa fa-calendar"></i>&nbsp;Date</th>
                            <th><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none">
                                    <path d="M12 22C17.5228 22 22 17.5228 22 12H19C19 15.866 15.866 19 12 19V22Z" fill="currentColor"></path>
                                    <path d="M2 12C2 6.47715 6.47715 2 12 2V5C8.13401 5 5 8.13401 5 12H2Z" fill="currentColor"></path>
                                </svg>&nbsp;Action</th>
                        </tr>
                    </thead>
                    <?PHP
              
             

               
             $id=$_GET['acc'];
                              

              $query="SELECT * from booking,bus,student,seat where seat.seat_id=booking.seat_id and booking.bus_id=bus.bus_id and booking.student_no=student.student_no and booking.student_no='$id'";
              $result=mysqli_query($conn,$query);
              
              $rows=mysqli_num_rows($result);
              
             
              
              if ($rows>0) {
                
                ?>
                    <tbody>
                    <?php
                             $x=1;                 
                                              while ($rows=mysqli_fetch_array($result)) {
                                            ?>
                        <tr>
                            <td><?php echo $x ?></td>
                            <td><?php echo $rows['seat_identify'] ?></td>
                            <td><?php echo $rows['bus_reg'] ?> (<?php echo $rows['destination'].'-'.$rows['time'] ?>)</td>
                            <td><?php echo $rows['date'] ?></td>
                            <td><a class="btn btn-sm" href="cancelbook.php?b=<?php echo $rows['booking_id'] ?>" title="Cancel Booking" type="button"><i  style="color: #a50544;" class="fa fa-ban"></i></a></td>
                        </tr>
                        <?php
                          $x++;                             
                  
                                                    }
                                                    ?>
                    </tbody>
                </table>
                <?php
                                                   
                                                }else{
                                                  ?>
                                                  <h3>No record(s)</h3>
                                                  <?php
                                                } ?>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/login-full-page-bs4.js"></script>
    <script src="assets/js/login-full-page-bs4-1.js"></script>
</body>

</html>