<!DOCTYPE html>
<html lang="en">


<?php

include 'connect.php'; 


if(!isset($_SESSION)) 
{ 
    session_start(); 
    $email=$_SESSION['email'];
    $id=$_SESSION['student_no'];
}   
   
?>




<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ST</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/css/animated-services.css">
    <link rel="stylesheet" href="assets/css/Customizable-Background--Overlay.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/FORM.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/login-full-page-bs4.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Login-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card-1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <section class="newsletter-subscribe">
        <div class="container" style="border-color: rgba(49,52,55,0);">
            <div class="intro"></div>
        </div>
        <div class="row login-form">
            <div class="col-md-4 offset-md-4">
                <p style="text-align: right;font-size: 19px;"><a href="account.php"><i class="fa fa-window-close" style="color: #a50544;"></i></a></p>
                    <h2 class="text-center" style="font-size: 15px;color: #a50544;"><i class="fa fa-bus"></i>&nbsp;Book seat</h2>
                 
                    <div class="table-responsive" style="font-size: 14px;">
                <table class="table table-striped table-sm" style="font-size: 12px;">
                    <thead>
                        <tr style="background: #a50544;color: rgb(255,255,255);">
                            <th>#</th>
                         
                            <th><i class="fa fa-bus"></i>&nbsp;Bus</th>
                            <th><i class="fa fa-info-circle"></i>&nbsp;Destination</th>
                            <th><i class="fa fa-clock-o" aria-hidden="true"></i> Time</th>
                            <th><i class="la la-share-alt"></i>Seat</th>
                            <th><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none">
                                    <path d="M12 22C17.5228 22 22 17.5228 22 12H19C19 15.866 15.866 19 12 19V22Z" fill="currentColor"></path>
                                    <path d="M2 12C2 6.47715 6.47715 2 12 2V5C8.13401 5 5 8.13401 5 12H2Z" fill="currentColor"></path>
                                </svg>&nbsp;Book</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?PHP          
         
         $result=mysqli_query($conn,"SELECT * from bus");
         $rows=mysqli_num_rows($result);        
         
         if ($rows>0) {
           
         $x=1;
        while ($rows=mysqli_fetch_array($result)) {
            
            ?>
             <form data-aos="fade-up-right" data-aos-duration="950" data-aos-delay="550" action="seating.php?s=<?php echo $rows['bus_id'] ?>" name="form" onsubmit="return validateForm();" method="post" class="custom-form" style="border-top-color: rgb(255,255,255);">
                   
                        <tr>
                            <td><?php echo $x ?></td>
                            <input style="display:none" type="text" name="busid" value="<?php echo $rows['bus_id'] ?>">
                            <td><?php echo $rows['bus_reg'] ?></td>
                            <td><?php echo $rows['destination'] ?></td>
                            <td><?php echo $rows['time'] ?></td>
                            <td> <select name="seat" >
                            <?PHP          
         $idd=$rows['bus_id'];
         $r=mysqli_query($conn,"SELECT * from seat where taken='0' and bus_id='$idd'");
         $ro=mysqli_num_rows($r);        
         
         if ($ro>0) {
           
         
        while ($ro=mysqli_fetch_array($r)) {
            
            ?>
                                <option value="<?php echo $ro['seat_id'] ?>"><?php echo $ro['seat_identify'] ?></option>
                                <?php }
         }
                        ?>
                            </select></td>
                            <td><button  type="submit"  style="color:#a50544">Book Seat</button></td>
                        </tr>
                        </form>
                        <?php
                    $x++;    
                    }
         }
                        ?>
                    </tbody>
                </table>
            </div>
                
            </div>
        </div>
    </section>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/login-full-page-bs4.js"></script>
    <script src="assets/js/login-full-page-bs4-1.js"></script>
</body>

</html>