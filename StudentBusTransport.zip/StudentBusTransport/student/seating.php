<?php 

include 'connect.php'; 


if(!isset($_SESSION)) 
{ 
    session_start(); 
    $email=$_SESSION['email'];
    $id=$_SESSION['student_no'];
} 


$bus_id=$_POST['busid'];
$seat=$_POST['seat'];

$sql="INSERT INTO booking(student_no,seat_id,bus_id,complete) 
                VALUES ('$id','$seat','$bus_id','0')";
    
    
    $command="UPDATE seat
    SET taken='1' Where seat_id='$seat'";
    $edit=mysqli_query($conn,$command);
                        
    
                if(mysqli_query($conn,$sql))
                {
        
          echo '<script type="text/javascript">alert("Seat Succesfully booked "); window.location = "account.php";</script>';
             
                                                             
              }
              else{
                
               die("<h3>unsuccessfully not registered </h3>".mysqli_error($conn));
             
             }




?>