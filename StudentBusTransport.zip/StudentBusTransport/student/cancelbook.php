<?php
include 'connect.php';

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 
$id=$_GET['b'];


$query1="SELECT * from booking,bus,student,seat where seat.seat_id=booking.seat_id and booking.bus_id=bus.bus_id and booking.student_no=student.student_no and booking.booking_id='$id'";
              
$result1=mysqli_query($conn,$query1) or die(mysqli_error($conn));
$row1=mysqli_fetch_array($result1);
$seatid=$row1['seat_id'];

    $sql=" DELETE From booking WHERE booking_id='$id'";
    $result=mysqli_query($conn,$sql);
  
    $command="UPDATE seat
    SET taken='0' Where seat_id='$seatid'";
    $edit=mysqli_query($conn,$command);

    if (!$result) {
    	echo "db access denied ".mysqli_error();
    }else{
      echo '<script>alert("booking Cancelled.");window.location = "account.php";</script>';
  }
  

?>