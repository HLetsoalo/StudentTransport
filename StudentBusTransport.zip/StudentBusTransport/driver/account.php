<!DOCTYPE html>
<html lang="en">
<?php
    include 'connect.php';
    //cart Check
   
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
     
      if(!isset($_SESSION)) 
      { 
          session_start(); 
          $email=$_SESSION['email'];
          $id=$_SESSION['driver_no'];
      }


    ?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ST</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/css/animated-services.css">
    <link rel="stylesheet" href="assets/css/Customizable-Background--Overlay.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/FORM.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/login-full-page-bs4.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Login-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card-1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <nav class="navbar navbar-light navigation-clean">
        <div class="container">
            <div class="collapse navbar-collapse" id="navcol-1" style="font-size: 13px;">
               
            </div>
            <?PHP                

              $query="SELECT * from driver where driver_no='$id'";
              $result=mysqli_query($conn,$query);
              
              $rows=mysqli_num_rows($result);
                  
              
              if ($rows>0) {
                
                ?>
                <?php
                    while ($rows=mysqli_fetch_array($result)) {

                
                  ?>
            <div class="dropdown">
                <a aria-expanded="false" data-toggle="dropdown" href="#" style="color: #a50544;"><i class="icon ion-android-menu"></i>&nbsp;Menu</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="update.php?acc=<?php echo $rows['driver_no']?>" style="color: #a50544;font-size: 14px;"><i class="fa fa-user"></i>&nbsp;Update Account</a>
                    <a class="dropdown-item" href="deleteaccount.php?acc=<?php echo $rows['driver_no']?>" style="color: #a50544;font-size: 14px;"><i class="fa fa-trash"></i>&nbsp;Delete Account</a>
                    <a class="dropdown-item" href="addbus.php?acc=<?php echo $rows['driver_no']?>" style="color: #a50544;font-size: 14px;"><i class="fa fa-bus"></i>&nbsp;Add Bus</a>
                    <a class="dropdown-item" href="seats.php?acc=<?php echo $rows['driver_no']?>" style="color: #a50544;font-size: 14px;"><i class="fa fa-bus"></i>&nbsp;View Bus Seats</a>
                    <a class="dropdown-item" href="booking.php?acc=<?php echo $rows['driver_no']?>" style="color: #a50544;font-size: 14px;"><i class="fa fa-list-alt"></i>&nbsp;View Bookings</a>
                    <a class="dropdown-item" href="../logout.php" style="font-size: 14px;color: #a50544;"><i class="fa fa-sign-out"></i>&nbsp;Sign Out</a>
                </div>
            </div>
        </div>
    </nav>
    <h3 style="font-size: 16px;text-align: center;color: #a50544;">Bus Driver Account</h3>
    <div class="text-center profile-card" style="margin:15px;background-color:#ffffff;">
    
        <div style="padding-top: 77px;"><img class="rounded-circle" style="margin-top: -70px;filter: hue-rotate(318deg);" src="assets/img/user-icon.jpg" height="150px">
            <h3 style="font-size: 16px;color: #a50544;"><?php echo $rows['first_name'].' '.$rows['last_name']?> (Driver)</h3>
            <h3 style="font-size: 15px;font-weight: 400;color: #a50544;"><i class="fa fa-envelope-o"></i>&nbsp;<?php echo $rows['email'] ?></h3>
           
        </div>
        
        <?php
                  
                }
                ?>

<?php
              }
                ?>
               

    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/login-full-page-bs4.js"></script>
    <script src="assets/js/login-full-page-bs4-1.js"></script>
</body>

</html>