<!DOCTYPE html>
<html lang="en">
<?php
    include 'connect.php';
    //cart Check
   
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
      
      if(!isset($_SESSION)) 
      { 
          session_start(); 
          $email=$_SESSION['email'];
          $id=$_SESSION['driver_no'];
      }
      $qry="SELECT * from driver,bus where driver.email='$email' and driver.driver_no=bus.driver_no";
      $res=mysqli_query($conn,$qry);
    
      $data=mysqli_fetch_array($res);
     $busid=$data['bus_id'];

if(isset($_POST['add']))
{


$seat=$_POST['seat'];



    $query="select * from seat where bus_id='$busid' and seat_identify='$seat'";

    $result=mysqli_query($conn,$query) or die(mysqli_error($conn));
    
    $row=mysqli_fetch_array($result);
    
    if($row['seat_identify']==$seat)
    {
    
    
     echo '<script type="text/javascript">alert("Seat exist."); window.location = "seats.php";</script>';
    
    }                         
    else{
    
    $sql="INSERT INTO seat(bus_id,seat_identify,taken) 
                VALUES ('$busid','$seat','0')";
    
    
    
                        
    
                if(mysqli_query($conn,$sql))
                {
        
          echo '<script type="text/javascript">alert("Seat added."); window.location = "seats.php";</script>';
             
                                                             
              }
              else{
                
               die("<h3>unsuccessfully not registered </h3>".mysqli_error($conn));
             
             }
           }




}

    ?>




<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ST</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/css/animated-services.css">
    <link rel="stylesheet" href="assets/css/Customizable-Background--Overlay.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/FORM.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/login-full-page-bs4.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Login-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card-1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<script>

    
function validateForm() 
{
var eseat=document.getElementById("eseat");


if(document.forms["form"]["seat"].value==""

 )
{

    eseat.innerHTML="<span style='color:red;''>"+" field should not be empty *</span>"


return false;


}else
{
//name 
var name=document.forms["form"]["seat"].value;


if(name=="")
{

   nerror.innerHTML="<span style='color:red;''>"+" field should not be empty *</span>";
  return false;

}else if(name.match(/^(?=.*[!@#\$%\^&\*])/))
{
eseat.innerHTML="<span style='color:red;''>"+" field should not contain special characters.*</span>";
return false;

}else
{

eseat.innerHTML=""; 
}

}
}
</script>
<body>
    <section class="newsletter-subscribe">
        <div class="container" style="border-color: rgba(49,52,55,0);">
            <div class="intro"></div>
        </div>
        <div class="row login-form">
            <div class="col-md-4 offset-md-4">
                <form data-aos="fade-up-right" data-aos-duration="950" data-aos-delay="550" action="" name="form" onsubmit="return validateForm();" method="post" class="custom-form" style="border-top-color: rgb(255,255,255);">
                    <p style="text-align: right;font-size: 19px;"><a href="seats.php"><i class="fa fa-window-close" style="color: #a50544;"></i></a></p>
                    <h2 class="text-center" style="font-size: 15px;color: #a50544;"><i class="fa fa-bus"></i>&nbsp;Add Seat for bus (<?php echo $data['bus_reg'] ?>)</h2>
                    <div class="form-group"><input class="form-control form-control-sm" type="text" placeholder="Seat Code E.g A1,A2..." name="seat" id="seat" style="border-color: rgb(255,255,255);"><span id="eseat"></span></div>
                     <button class="btn btn-light btn-block submit-button" type="submit" name="add"  style="background: #a50544;">Add</button>
                 
                </form>
            </div>
        </div>
    </section>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/login-full-page-bs4.js"></script>
    <script src="assets/js/login-full-page-bs4-1.js"></script>
</body>

</html>