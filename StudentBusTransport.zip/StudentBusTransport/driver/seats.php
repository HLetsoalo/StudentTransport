<!DOCTYPE html>
<html lang="en">
<?php
    include 'connect.php';
    //cart Check
   
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
      
      if(!isset($_SESSION)) 
      { 
          session_start(); 
          $email=$_SESSION['email'];
          $id=$_SESSION['driver_no'];
      }
      $qry="SELECT * from driver,bus where driver.email='$email' and driver.driver_no=bus.driver_no";
      $res=mysqli_query($conn,$qry);
    
      $data=mysqli_fetch_array($res);
      $busid=$data['bus_id'];


      $q="SELECT count(seat_id) as seac from seat where bus_id='$busid'";
      $r=mysqli_query($conn,$q);
    
      $d=mysqli_fetch_array($r);

    ?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ST</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/css/animated-services.css">
    <link rel="stylesheet" href="assets/css/Customizable-Background--Overlay.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/FORM.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/login-full-page-bs4.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Login-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card-1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <nav class="navbar navbar-light navigation-clean">
        <div class="container">
            <div class="collapse navbar-collapse" id="navcol-1" style="font-size: 13px;">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="index.html" style="color: #a50544;">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.html" style="color: #a50544;">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="menu.html" style="color: #a50544;">Login | Register</a></li>
                </ul>
            </div>
            <div class="dropdown"><a aria-expanded="false" data-toggle="dropdown" href="#" style="color: #a50544;"><i class="icon ion-android-menu"></i>&nbsp;Menu</a>
            <div class="dropdown-menu">
                   
                    <a class="dropdown-item" href="account.php" style="color: #a50544;font-size: 14px;"><i class="fa fa-arrow-left"></i>&nbsp;Back</a>
                   
                </div>
        </div>
    </nav>

    <h3 style="font-size: 16px;text-align: center;color: #a50544;">Seats for bus(<?php echo $data['bus_reg']?>)</h3>

    <div class="text-center profile-card" style="margin:15px;background-color:#ffffff;">
        <div>
        <h3 style="font-size: 14px;text-align: left;color: #a50544;"><a style="font-size: 12px;background: #a50544;color: rgb(255,255,255);" class="btn" href="addseat.php?s=<?php echo $data['bus_id'] ?>"><i class="fa fa-plus-circle"></i> Add Seat(<?php echo $d['seac']?>)</a></h3>
            <div class="table-responsive" style="font-size: 14px;">
            <?PHP
              
             

               
              
                                
  
                $query="SELECT * from seat where bus_id='$busid'";
                $result=mysqli_query($conn,$query);
                
                $rows=mysqli_num_rows($result);
                
               
                
                if ($rows>0) {
                  
                  ?>
                <table class="table table-striped table-sm">
                    <thead>
                        <tr style="background: #a50544;color: rgb(255,255,255);">
                           
                            <th><i class="la la-share-alt"></i>Seat</th>
                           
                           
                            <th><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none">
                                    <path d="M12 22C17.5228 22 22 17.5228 22 12H19C19 15.866 15.866 19 12 19V22Z" fill="currentColor"></path>
                                    <path d="M2 12C2 6.47715 6.47715 2 12 2V5C8.13401 5 5 8.13401 5 12H2Z" fill="currentColor"></path>
                                </svg>&nbsp;Action</th>
                        </tr>
                    </thead>
                    
                  
                    <tbody>
                    <?php
                                                            while ($rows=mysqli_fetch_array($result)) {
                                                          ?>
                        <tr>
                           
                            <td><?php echo $rows['seat_identify'] ?></td>
                          
                            
                            <td><a class="btn btn-sm" href="deleteseat.php?s=<?php echo $rows['seat_id']?>" type="button"><i class="fa fa-trash-o" style="color: #a50544;"></i></a></td>
                        </tr>
                       <?php
                  
                }
                ?>  
                    </tbody>
                </table>
                                                              
                  <?php
            }else{
              ?>
              <h3 style="color: #a50544;font-size:14px;text-align:center">No record(s)</h3>
              <?php
                              
            } ?>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/login-full-page-bs4.js"></script>
    <script src="assets/js/login-full-page-bs4-1.js"></script>
</body>

</html>