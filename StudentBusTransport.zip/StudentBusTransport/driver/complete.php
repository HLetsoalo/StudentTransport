<?php
include 'connect.php';

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 
$id=$_GET['acc'];


  
    $command="UPDATE seat
    SET taken='0' Where bus_id='$id'";
    $edit=mysqli_query($conn,$command);

    if (!$edit) {
    	echo "db access denied ".mysqli_error();
    }else{
      echo '<script>alert("Trip complete");window.location = "account.php";</script>';
  }
  

?>