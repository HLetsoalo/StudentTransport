<!DOCTYPE html>
<html lang="en">
<?php
 
 include 'connect.php'; 
if(isset($_POST['email']) && isset($_POST['password'])){
 //Assign

$username=$_POST['email'];
$password=md5($_POST['password']);




//driver
$query1="select * from driver where email='$username'and password='$password'";
$result1=mysqli_query($conn,$query1) or die(mysqli_error($conn));
$row1=mysqli_fetch_array($result1);

//student
$query2="select * from student where email='$username'and password='$password'";
$result2=mysqli_query($conn,$query2) or die(mysqli_error($conn));
$row2=mysqli_fetch_array($result2);

//admin
$query3="select * from 	admin where email='$username'and password='$password'";
$result3=mysqli_query($conn,$query3) or die(mysqli_error($conn));
$row3=mysqli_fetch_array($result3);


if($row1['email']==$username && $row1['password']==$password)//driver
{
    session_start();

   
    $_SESSION['email']=$row1['email'];
    $email=$_SESSION['email'];
    $_SESSION['driver_no']=$row1['driver_no'];
    $id=$_SESSION['driver_no'];
   
    
echo '<script>alert("Login was successful.");window.location = "../driver/account.php";</script>';  
    

}elseif($row2['email']==$username && $row2['password']==$password)//student
{
    session_start();

   
    $_SESSION['email']=$row2['email'];
    $email=$_SESSION['email'];
    $_SESSION['student_no']=$row2['student_no'];
    $id=$_SESSION['student_no'];
   
    
echo '<script>alert("Login was successful.");window.location = "../student/account.php";</script>';  
    

}elseif($row3['email']==$username && $row3['password']==$password)//admin
{
    session_start();

   
    $_SESSION['email']=$row3['email'];
    $email=$_SESSION['email'];
    $_SESSION['admin_id']=$row3['admin_id'];
    $id=$_SESSION['admin_id'];
   
    
echo '<script>alert("Login was successful.");window.location = "../student/account.php";</script>';  
    

}else
{


echo '<script>alert("Wrong login credentials.");window.location = "sign-in.php";</script>';  
 exit;

}

}

?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ST</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/css/animated-services.css">
    <link rel="stylesheet" href="assets/css/Customizable-Background--Overlay.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/FORM.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
    <link rel="stylesheet" href="assets/css/login-full-page-bs4.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Newsletter-Subscription-Form.css">
    <link rel="stylesheet" href="assets/css/Pretty-Login-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Card-1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<script>

    
        function validateForm() 
        {
        var uerror=document.getElementById("uerror");
        var perror=document.getElementById("perror");
     

        //account type

        
        if(document.forms["form"]["email"].value=="" && document.forms["form"]["password"].value=="")
        {
     
        uerror.innerHTML="<span style='color:red;''>"+" email required *</span>"
        perror.innerHTML="<span style='color:red;''>"+" password required *</span>"
       
        
        return false;
        
        }
        else
        {

            

        if(document.forms["form"]["email"].value=="")
        {
        
        uerror.innerHTML="<span style='color:red;''>"+" email required *</span>"
        
        return false;
        
        }else
        {
         
            uerror.innerHTML="";

        }
  
        
        if(document.forms["form"]["password"].value=="")
        {
        
        perror.innerHTML="<span style='color:red;''>"+" password required *</span>"
        
        return false;
        
        }
        else
        {

            perror.innerHTML="";


        }

//
    
        }
        
        }
        </script>
<body>
    <section class="newsletter-subscribe">
        <div class="container" style="border-color: rgba(49,52,55,0);">
            <div class="intro"></div>
        </div>
        <div class="row login-form">
            <div class="col-md-4 offset-md-4">
                <form data-aos="fade-up-right" data-aos-duration="950" data-aos-delay="550" class="custom-form" style="border-top-color: rgb(255,255,255);"  name="form" onsubmit="return validateForm();" method="post" >
                    <p style="text-align: right;font-size: 19px;"><a href="menu.php"><i class="fa fa-window-close" style="color: #a50544;"></i></a></p>
                    <h2 class="text-center" style="font-size: 15px;color: #a50544;"><i class="fa fa-user-circle"></i>&nbsp;Login To Account</h2>
                    <div class="form-group"><input class="form-control form-control-sm" type="email" name="email" id="email" placeholder="Email" style="border-color: rgb(255,255,255);"><span id="uerror"></span></div>
                    <div class="form-group"><input class="form-control form-control-sm" type="password" name="password" id="password" placeholder="Password" style="border-color: rgb(255,255,255);"><span id="perror"></span></div>
                    <button class="btn btn-light btn-block submit-button" name="login" type="submit" style="background: #a50544;">Login</button>
                    <p style="color: #a50544;font-size: 14px;">Don't Have account?&nbsp;<a href="sign-up.php" style="color: #a50544;">Click Here!</a></p>
                </form>
            </div>
        </div>
    </section>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="assets/js/login-full-page-bs4.js"></script>
    <script src="assets/js/login-full-page-bs4-1.js"></script>
</body>

</html>